"use client"

import type React from "react"

import { useState, useEffect } from "react"
import {
  Plus,
  Calendar,
  DollarSign,
  User,
  Percent,
  Calculator,
  Trash2,
  CreditCard,
  Filter,
  CheckCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface Debt {
  id: string
  borrowerName: string
  principalAmount: number
  interestAmount: number
  paidPrincipal: number
  paidInterest: number
  dueDate: string
  createdDate: string
}

type FilterType = "all" | "unpaid" | "partial" | "paid"

export default function DebtTracker() {
  const [debts, setDebts] = useState<Debt[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false)
  const [selectedDebt, setSelectedDebt] = useState<Debt | null>(null)
  const [filter, setFilter] = useState<FilterType>("all")
  const [formData, setFormData] = useState({
    borrowerName: "",
    principalAmount: "",
    interestAmount: "",
    dueDate: "",
  })
  const [paymentData, setPaymentData] = useState({
    principalPayment: "",
    interestPayment: "",
  })

  // Load debts from localStorage on component mount
  useEffect(() => {
    const savedDebts = localStorage.getItem("debts")
    if (savedDebts) {
      setDebts(JSON.parse(savedDebts))
    }
  }, [])

  // Save debts to localStorage whenever debts change
  useEffect(() => {
    localStorage.setItem("debts", JSON.stringify(debts))
  }, [debts])

  const getRemainingPrincipal = (debt: Debt) => {
    return Math.max(0, debt.principalAmount - debt.paidPrincipal)
  }

  const getRemainingInterest = (debt: Debt) => {
    return Math.max(0, debt.interestAmount - debt.paidInterest)
  }

  const getTotalAmount = (debt: Debt) => {
    return debt.principalAmount + debt.interestAmount
  }

  const getPaymentStatus = (debt: Debt) => {
    const totalRemaining = getRemainingPrincipal(debt) + getRemainingInterest(debt)
    if (totalRemaining === 0) return "paid"
    if (debt.paidPrincipal > 0 || debt.paidInterest > 0) return "partial"
    return "unpaid"
  }

  const isOverdue = (dueDate: string) => {
    return new Date(dueDate) < new Date()
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.borrowerName || !formData.principalAmount || !formData.interestAmount || !formData.dueDate) {
      alert("กรุณากรอกข้อมูลให้ครบถ้วน")
      return
    }

    const newDebt: Debt = {
      id: Date.now().toString(),
      borrowerName: formData.borrowerName,
      principalAmount: Number.parseFloat(formData.principalAmount),
      interestAmount: Number.parseFloat(formData.interestAmount),
      paidPrincipal: 0,
      paidInterest: 0,
      dueDate: formData.dueDate,
      createdDate: new Date().toISOString().split("T")[0],
    }

    setDebts([...debts, newDebt])
    setFormData({
      borrowerName: "",
      principalAmount: "",
      interestAmount: "",
      dueDate: "",
    })
    setIsDialogOpen(false)
  }

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedDebt) return

    const principalPayment = Number.parseFloat(paymentData.principalPayment) || 0
    const interestPayment = Number.parseFloat(paymentData.interestPayment) || 0

    const updatedDebts = debts.map((debt) => {
      if (debt.id === selectedDebt.id) {
        return {
          ...debt,
          paidPrincipal: Math.min(debt.principalAmount, debt.paidPrincipal + principalPayment),
          paidInterest: Math.min(debt.interestAmount, debt.paidInterest + interestPayment),
        }
      }
      return debt
    })

    setDebts(updatedDebts)
    setPaymentData({ principalPayment: "", interestPayment: "" })
    setIsPaymentDialogOpen(false)
    setSelectedDebt(null)
  }

  const openPaymentDialog = (debt: Debt) => {
    setSelectedDebt(debt)
    setIsPaymentDialogOpen(true)
  }

  const deleteDebt = (id: string) => {
    setDebts(debts.filter((debt) => debt.id !== id))
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("th-TH", {
      style: "currency",
      currency: "THB",
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("th-TH", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const getFilteredDebts = () => {
    return debts.filter((debt) => {
      const status = getPaymentStatus(debt)
      if (filter === "all") return true
      return status === filter
    })
  }

  const getTotalDebtAmount = () => {
    return debts.reduce((total, debt) => total + getTotalAmount(debt), 0)
  }

  const getTotalPrincipal = () => {
    return debts.reduce((total, debt) => total + debt.principalAmount, 0)
  }

  const getTotalInterest = () => {
    return debts.reduce((total, debt) => total + debt.interestAmount, 0)
  }

  const getTotalPaid = () => {
    return debts.reduce((total, debt) => total + debt.paidPrincipal + debt.paidInterest, 0)
  }

  const filteredDebts = getFilteredDebts()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">📋 แอพจดหนี้</h1>
          <p className="text-gray-600">จัดการและติดตามหนี้สินของคุณอย่างง่ายดาย</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ยอดรวมทั้งหมด</CardTitle>
              <Calculator className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-purple-600">{formatCurrency(getTotalDebtAmount())}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">เงินต้นรวม</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-blue-600">{formatCurrency(getTotalPrincipal())}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ดอกเบี้ยรวม</CardTitle>
              <Percent className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-orange-600">{formatCurrency(getTotalInterest())}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">ได้รับคืนแล้ว</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-green-600">{formatCurrency(getTotalPaid())}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">คงเหลือ</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold text-red-600">
                {formatCurrency(
                  debts.reduce((total, debt) => total + getRemainingPrincipal(debt) + getRemainingInterest(debt), 0),
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Controls */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg">
                <Plus className="mr-2 h-4 w-4" />
                เพิ่มหนี้ใหม่
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>เพิ่มหนี้ใหม่</DialogTitle>
                <DialogDescription>กรอกข้อมูลหนี้ที่ต้องการเพิ่มลงในระบบ</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="borrowerName">ชื่อผู้ยืม</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="borrowerName"
                      placeholder="ชื่อผู้ยืมเงิน"
                      value={formData.borrowerName}
                      onChange={(e) => setFormData({ ...formData, borrowerName: e.target.value })}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="principalAmount">จำนวนเงินต้น (บาท)</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="principalAmount"
                      type="number"
                      placeholder="0.00"
                      value={formData.principalAmount}
                      onChange={(e) => setFormData({ ...formData, principalAmount: e.target.value })}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="interestAmount">ดอกเบี้ย (บาท)</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="interestAmount"
                      type="number"
                      placeholder="0.00"
                      value={formData.interestAmount}
                      onChange={(e) => setFormData({ ...formData, interestAmount: e.target.value })}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dueDate">วันครบกำหนดชำระ</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="dueDate"
                      type="date"
                      value={formData.dueDate}
                      onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                      className="pl-10"
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  เพิ่มหนี้
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <Select value={filter} onValueChange={(value: FilterType) => setFilter(value)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ทั้งหมด</SelectItem>
                <SelectItem value="unpaid">ยังไม่ได้รับคืน</SelectItem>
                <SelectItem value="partial">ได้รับคืนบางส่วน</SelectItem>
                <SelectItem value="paid">ได้รับคืนครบแล้ว</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Payment Dialog */}
        <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>บันทึกการชำระเงิน</DialogTitle>
              <DialogDescription>{selectedDebt && `บันทึกการชำระเงินของ ${selectedDebt.borrowerName}`}</DialogDescription>
            </DialogHeader>
            {selectedDebt && (
              <form onSubmit={handlePayment} className="space-y-4">
                <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="text-sm text-muted-foreground">เงินต้นคงเหลือ</p>
                    <p className="font-semibold text-blue-600">{formatCurrency(getRemainingPrincipal(selectedDebt))}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">ดอกเบี้ยคงเหลือ</p>
                    <p className="font-semibold text-orange-600">
                      {formatCurrency(getRemainingInterest(selectedDebt))}
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="principalPayment">ชำระเงินต้น (บาท)</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="principalPayment"
                      type="number"
                      placeholder="0.00"
                      value={paymentData.principalPayment}
                      onChange={(e) => setPaymentData({ ...paymentData, principalPayment: e.target.value })}
                      className="pl-10"
                      max={getRemainingPrincipal(selectedDebt)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="interestPayment">ชำระดอกเบี้ย (บาท)</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="interestPayment"
                      type="number"
                      placeholder="0.00"
                      value={paymentData.interestPayment}
                      onChange={(e) => setPaymentData({ ...paymentData, interestPayment: e.target.value })}
                      className="pl-10"
                      max={getRemainingInterest(selectedDebt)}
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  บันทึกการชำระ
                </Button>
              </form>
            )}
          </DialogContent>
        </Dialog>

        {/* Debts List */}
        <div className="space-y-4">
          {filteredDebts.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <div className="text-6xl mb-4">📝</div>
                <h3 className="text-lg font-semibold mb-2">{filter === "all" ? "ยังไม่มีหนี้ในระบบ" : "ไม่มีหนี้ในหมวดหมู่นี้"}</h3>
                <p className="text-muted-foreground text-center">
                  {filter === "all" ? "เริ่มต้นโดยการเพิ่มหนี้แรกของคุณ" : "ลองเปลี่ยน Filter เพื่อดูหนี้อื่น"}
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredDebts.map((debt) => {
              const status = getPaymentStatus(debt)
              const remainingTotal = getRemainingPrincipal(debt) + getRemainingInterest(debt)

              return (
                <Card
                  key={debt.id}
                  className={`transition-all hover:shadow-lg ${
                    isOverdue(debt.dueDate) && remainingTotal > 0 ? "border-red-200 bg-red-50" : ""
                  }`}
                >
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <User className="h-5 w-5" />
                          {debt.borrowerName}
                          {isOverdue(debt.dueDate) && remainingTotal > 0 && (
                            <Badge variant="destructive">เกินกำหนด</Badge>
                          )}
                          {status === "paid" && <Badge className="bg-green-500">ชำระครบแล้ว</Badge>}
                          {status === "partial" && <Badge variant="secondary">ชำระบางส่วน</Badge>}
                        </CardTitle>
                        <CardDescription>วันที่ให้ยืม: {formatDate(debt.createdDate)}</CardDescription>
                      </div>
                      <div className="flex gap-2">
                        {remainingTotal > 0 && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openPaymentDialog(debt)}
                            className="text-green-600 hover:text-green-700 hover:bg-green-50"
                          >
                            <CreditCard className="h-4 w-4 mr-1" />
                            ชำระ
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteDebt(debt.id)}
                          className="text-red-500 hover:text-red-700 hover:bg-red-100"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="summary" className="w-full">
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="summary">สรุป</TabsTrigger>
                        <TabsTrigger value="details">รายละเอียด</TabsTrigger>
                      </TabsList>

                      <TabsContent value="summary" className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                          <div className="space-y-1">
                            <p className="text-sm text-muted-foreground">ยอดรวมทั้งหมด</p>
                            <p className="text-lg font-bold text-purple-600">{formatCurrency(getTotalAmount(debt))}</p>
                          </div>

                          <div className="space-y-1">
                            <p className="text-sm text-muted-foreground">ได้รับคืนแล้ว</p>
                            <p className="text-lg font-semibold text-green-600">
                              {formatCurrency(debt.paidPrincipal + debt.paidInterest)}
                            </p>
                          </div>

                          <div className="space-y-1">
                            <p className="text-sm text-muted-foreground">คงเหลือ</p>
                            <p className="text-lg font-bold text-red-600">{formatCurrency(remainingTotal)}</p>
                          </div>

                          <div className="space-y-1">
                            <p className="text-sm text-muted-foreground">ครบกำหนด</p>
                            <p
                              className={`text-sm font-medium ${
                                isOverdue(debt.dueDate) && remainingTotal > 0 ? "text-red-600" : "text-gray-900"
                              }`}
                            >
                              {formatDate(debt.dueDate)}
                            </p>
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="details" className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-3">
                            <h4 className="font-semibold text-blue-600">เงินต้น</h4>
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-sm text-muted-foreground">ยอดรวม:</span>
                                <span className="font-medium">{formatCurrency(debt.principalAmount)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-sm text-muted-foreground">คืนแล้ว:</span>
                                <span className="font-medium text-green-600">{formatCurrency(debt.paidPrincipal)}</span>
                              </div>
                              <div className="flex justify-between border-t pt-2">
                                <span className="text-sm font-medium">คงเหลือ:</span>
                                <span className="font-bold text-red-600">
                                  {formatCurrency(getRemainingPrincipal(debt))}
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="space-y-3">
                            <h4 className="font-semibold text-orange-600">ดอกเบี้ย</h4>
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-sm text-muted-foreground">ยอดรวม:</span>
                                <span className="font-medium">{formatCurrency(debt.interestAmount)}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-sm text-muted-foreground">คืนแล้ว:</span>
                                <span className="font-medium text-green-600">{formatCurrency(debt.paidInterest)}</span>
                              </div>
                              <div className="flex justify-between border-t pt-2">
                                <span className="text-sm font-medium">คงเหลือ:</span>
                                <span className="font-bold text-red-600">
                                  {formatCurrency(getRemainingInterest(debt))}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              )
            })
          )}
        </div>
      </div>
    </div>
  )
}
